package com.example.expensemanager;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.expensemanager.databinding.ActivityUpdateBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class UpdateActivity extends AppCompatActivity {
    ActivityUpdateBinding binding;
    String newType;
    FirebaseFirestore firebaseFirestore;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());

        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        String id = getIntent().getStringExtra("id");
        String amount = getIntent().getStringExtra("amount");
        String note = getIntent().getStringExtra("note");
        String type = getIntent().getStringExtra("type");

        binding.userAmountAdd.setText(amount);
        binding.userNoteAdd.setText(note);

        switch (type) {
            case "Income":
                newType = "Income";
                binding.incomeCheckBox.setChecked(true);
                break;
            case "Expense":
                newType = "Expense";
                binding.expenseCheckBox.setChecked(true);
                break;
        }

        binding.incomeCheckBox.setOnClickListener(view -> {
            newType = "Income";
            binding.incomeCheckBox.setChecked(true);
            binding.expenseCheckBox.setChecked(false);
        });

        binding.expenseCheckBox.setOnClickListener(view -> {
            newType = "Expense";
            binding.incomeCheckBox.setChecked(false);
            binding.expenseCheckBox.setChecked(true);
        });

        // Update button listener
        binding.btnUpdateTransaction.setOnClickListener(view -> {
            String updatedAmount = binding.userAmountAdd.getText().toString();
            String updatedNote = binding.userNoteAdd.getText().toString();
            firebaseFirestore.collection("Expenses").document(firebaseAuth.getUid())
                    .collection("Notes").document(id)
                    .update("amount", updatedAmount, "note", updatedNote, "type", newType)
                    .addOnSuccessListener(unused -> {
                        onBackPressed();
                        Toast.makeText(UpdateActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(UpdateActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        // Delete button listener
        binding.btnDeleteTransaction.setOnClickListener(view -> {
            firebaseFirestore.collection("Expenses").document(firebaseAuth.getUid())
                    .collection("Notes").document(id).delete()
                    .addOnSuccessListener(unused -> {
                        onBackPressed();
                        Toast.makeText(UpdateActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(UpdateActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
